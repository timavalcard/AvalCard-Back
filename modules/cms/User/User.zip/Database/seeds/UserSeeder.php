<?php
namespace Mamad\User\Database\seeds;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Mamad\RolePermissions\Models\Role;
use Mamad\User\Models\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database Seeds.
     *
     * @return void
     */
    public function run()
    {
        User::truncate();
        factory(User::class,5)->create();

        User::create([
            "name"=>"admin",
            "email"=>"admin@admin.com",
            "password"=>Hash::make("admin")
        ])->assignRole(Role::ROLE_SUPER_ADMIN)->markEmailAsVerified();
    }
}
