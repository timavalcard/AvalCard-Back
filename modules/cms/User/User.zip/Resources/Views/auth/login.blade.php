@extends(config("theme.theme_mainContent_path"),["header"=>false,"footer"=>false])

@section("title","ورود به سایت")
@section('content')
<div class="container">



        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">



                <div class="form-my-account-content">
                    <div class="header-top-logo form-auth-logo" style="text-align:center">
                        <a href="/"><img src="{{ $header_options["logo"] }}" alt="اتریسا هوم"></a>
                        <svg xmlns="http://www.w3.org/2000/svg" width="193.213" height="100" viewBox="0 0 193.213 100">
                            <path id="Union_2" data-name="Union 2" d="M33.358-10a27,27,0,0,1-27-27v-73H172.9a27.164,27.164,0,0,0-26.678,26.669h0V-37a27,27,0,0,1-27,27ZM-20.311-110v0H6.358v26.708A27.158,27.158,0,0,0-20.311-110Z" transform="translate(20.311 110)" fill="#f4f4f4"/>
                        </svg>

                    </div>

                    <h2>ورود</h2>
                        <form class=" register-form login" method="POST" action="{{ route('auth.index') }}">
                            @csrf

                            <div class="form-group row">
                                <label for="email" class="col-md-2 p-0  col-form-label text-md-right">ایمیل</label>

                                <div  class="col-md-12">
                                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-md-2 p-0 col-form-label text-md-right">رمز عبور</label>

                                <div  class="col-md-12">
                                    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                    @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                        <label class="form-check-label" for="remember">
                                            مرا به خاطر بسپر
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-12 ">
                                    <button type="submit" class="btn btn-primary">
                                        ورود
                                    </button>

                                    @if (Route::has('password.request'))
                                        <a class="btn btn-link" href="{{ route('password.request') }}">
                                            رمز عبور خود را فراموش کرده اید؟

                                        </a>
                                    @endif
                                </div>
                            </div>
                        </form>
                    <ul class="nav nav-tabs">

                        <li class="">
                            <p>کاربر جدید هستید؟</p>
                            <a class="a-register" href="{{ route("register") }}">
                                <h4>ساخت حساب</h4>
                            </a></li>
                    </ul>
                </div>
            </div>

        </div>

</div>
@endsection
