
@extends(config("theme.theme_mainContent_path"),["header"=>false,"footer"=>false])

@section("title","بازگردانی گذرواژه")
@section('content')
    <div class="container">



        <div class="row justify-content-center">

            <div class="col-md-6 col-lg-4">



                <div class="form-my-account-content">

                    <div class="header-top-logo" style="text-align:center">
                        <a href="/"><img src="{{ $header_options["logo"] }}" alt="اتریسا هوم"></a>
                    </div>
                    <h2>بازگردانی گذرواژه</h2>
                    <form method="POST" action="{{ route('password.update') }}">
                        @csrf

                        <input type="hidden" name="token" value="{{ $token }}">

                        <div class="form-group row">
                            <label for="email" class="col-md-2 col-form-label text-md-right">ایمیل</label>

                            <div class="col-md-10">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $email ?? old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">پسورد</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">تایید پسورد</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">

                                <button type="submit" class="btn btn-primary">
                                    بازگردانی گذرواژه
                                </button>

                        </div>
                    </form>

                    <ul class="nav nav-tabs">

                        <li class="">

                            <a class="a-register" href="{{ route('auth.index') }}">
                                <h4>صفحه ورود</h4>
                            </a></li>
                    </ul>

                    <a class="return_homePage" href="/" style="margin-top: 20px;">
                        <i class="fa fa-angle-right"></i>
                        بازگشت به صفحه اصلی
                    </a>
                </div>
            </div>

        </div>

    </div>
@endsection


