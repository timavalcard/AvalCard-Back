


@extends(config("theme.theme_mainContent_path"),["header"=>false,"footer"=>false])

@section("title","تایید ادرس ایمیل")
@section('content')
    <div class="container">



        <div class="row justify-content-center">

            <div class="col-md-6 col-lg-4">



                <div class="form-my-account-content">
                    <div class="header-top-logo" style="text-align:center">
                        <a href="/"><img src="{{ $header_options["logo"] }}" alt="اتریسا هوم"></a>
                    </div>
                    <h2>تایید ادرس ایمیل</h2>

                    @if (session('resent'))
                        <div class="alert alert-success" role="alert">
                           لینک تایید دوباره برای ایمیل شما ارسال شد
                        </div>
                    @endif

                    قبل از درخواست مجدد ایمیل خود را بررسی کنید.
                    اگر ایمیل تایید را دریافت نکرده اید,
                    <form class="d-inline" method="POST" action="{{ route('verification.resend') }}">
                        @csrf
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline">برای ارسال مجدد کلیک کنید</button>.
                    </form>

                    <ul class="nav nav-tabs">

                        <li class="">

                            <a class="a-register" href="{{ route('auth.index') }}">
                                <h4>صفحه ورود</h4>
                            </a></li>
                    </ul>

                    <a class="return_homePage" href="/" style="margin-top: 20px;">
                        <i class="fa fa-angle-right"></i>
                        بازگشت به صفحه اصلی
                    </a>
                </div>
            </div>

        </div>

    </div>
@endsection

