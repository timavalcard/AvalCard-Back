<x-admin-panel-layout>
    <x-slot name="title">
        لیست کاربران
    </x-slot>
    <x-slot name="main">
        <table class="admin-table">
            <tr>
                <th>نام </th>
                <th>ایمیل</th>
                <th>تلفن همراه</th>
                <th>نقش کاربری</th>
                <th>وضعیت حساب</th>
                <th>مقاله ها</th>
                <th>تاریخ عضویت</th>
            </tr>
            @foreach($users as $user)
            <tr>
                <td><a href="{{ route("admin_edit_user",["id"=>$user->id]) }}">
                    {{ $user->name}}</a>
                    <div class="admin-table-actions"><a href="{{ route("admin_edit_user",["id"=>$user->id]) }}"><span>بروزرسانی</span></a>
                        <a class="admin-table-actions-delete"
                           href="{{ route("admin_delete_user",["id"=>$user->id]) }}"><span>حذف</span></a> <a href="#"><span>نمایش در سایت</span></a>
                    </div>
                </td>
                <td>{{ $user->email}}</td>
                <td>{{ $user->mobile}}</td>
                <td>
                    <ul>
                    @foreach($user->roles as $userRole)
                       <li>@lang($userRole->name)</li>
                    @endforeach
                    </ul>
                </td>
                <td>@lang($user->status)</td>
                <td>{{ $user->article()->count() }}</td>
                <td>{{ toShamsi($user->created_at) }}</td>
            </tr>        @endforeach
            <tr>
              <th>نام </th>
                <th>ایمیل</th>
                <th>تلفن همراه</th>
                <th>نقش کاربری</th>
                <th>وضعیت حساب</th>
                <th>مقاله ها</th>
                <th>تاریخ عضویت</th>
            </tr>
        </table>
        <div class="admin-paginator">
            {{ $users->links() }}
        </div>
        @includeIf("admin.partials.delete_modal")
    </x-slot>
</x-admin-panel-layout>
