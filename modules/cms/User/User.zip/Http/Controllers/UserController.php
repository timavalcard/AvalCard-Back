<?php

namespace Mamad\User\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Mamad\Media\Http\Requests\UserAddMediaRequest;
use Mamad\Media\Services\MediaFileService;
use Mamad\Order\Models\Order;
use Mamad\Order\Repository\OrderRepository;
use Mamad\Product\Repository\ProductRepository;
use Mamad\Product\Repository\ProductVariationRepository;
use Mamad\Product\Service\ProductService;
use Mamad\Product\Service\ProductVariation;
use Mamad\RolePermissions\Models\Role;
use Mamad\RolePermissions\Repositories\RoleRepo;
use Mamad\Shop\Service\ShopService;
use Mamad\User\Http\Requests\AddUserRequest;
use Mamad\User\Http\Requests\EditAccountRequest;
use Mamad\User\Http\Requests\EditUserRequest;
use Mamad\User\Models\User;
use Mamad\User\Repositories\UserRepository;

class UserController extends Controller
{
    //theme functions

    public function edit_avatar(UserAddMediaRequest $request){
        $image=MediaFileService::publicUpload($request->user_image);
        UserRepository::add_meta([["name"=>"profile_avatar","value"=>$image->id]]);
        toastMessage("image profile شما با موفقیت upload شد");
        return back();
    }

    public function courses(){
        $courses=auth()->user()->courses;

        return view(config("theme.theme_path")."account.courses",["courses"=>$courses]);

    }
    public function wishlist(){
        $wishlists=auth()->user()->wishlist;

        return view(config("theme.theme_path")."account.wishlist",["wishlists"=>$wishlists]);

    }
    public function account(){
        $user=auth()->user();
        $orders=OrderRepository::user_all_orders();
        return view(config("theme.theme_path")."account.index",["user"=>$user,"orders"=>$orders]);
    }
    public function comments(){
        $user=auth()->user();
        $comments=$user->comments;
        return view(config("theme.theme_path")."account.comments",["comments"=>$comments]);

    }
    public function address(){
        $user=auth()->user();
        $address=get_user_meta($user->id,"address");
        if($address){
            $address=$address->meta_value;
        }
        $billing=UserRepository::get_billing_meta();
        return view(config("theme.theme_path")."account.address",["address"=>$address,"billing"=>$billing]);

    }
    public function delete_address($index){
        $user=auth()->user();
        $address=get_user_meta($user->id,"address");
        if($address){
            $address=$address->meta_value;
            unset($address[$index]);
            update_user_meta($user->id,"address",$address);
        }
        return back();
    }


    public function add_address(Request $request){
        $user=auth()->user();
        $address=get_user_meta($user->id,"address");
        if(!$address){
            $data=[];
            foreach ($request->all() as $key=>$item) {

                if(str_contains($key,"billing_")){
                    $data[$key]=$item;
                }
            }
            $address[0]=$data;
            update_user_meta($user->id,"address",$address);
        } else{

                $address=$address->meta_value;

            $data=[];
            foreach ($request->all() as $key=>$item) {

                if(str_contains($key,"billing_")){
                    $data[$key]=$item;
                }
            }
            $address[]=$data;

            update_user_meta($user->id,"address",$address);
        }
        return back();
    }

    public function edit_account_form(){
        $user=auth()->user();
        $user_data=UserRepository::get_all_meta($user);

        return view(config("theme.theme_path")."account.edit",["user"=>$user,"user_data"=>$user_data]);

    }

    public function edit_account(EditAccountRequest $request){
        $user=auth()->user();
        $data=$request->all();
        if (!empty($request->password)) {
            $data["password"]=bcrypt($request->new_password);
        }
        UserRepository::edit_account($user,$data);
        return back();
    }

    public function orders(){
        $orders=OrderRepository::user_all_orders();
        return view(config("theme.theme_path")."account.orders",["orders"=>$orders]);
    }
    public function transactions(){
        $transactions=auth()->user()->transactions;
        return view(config("theme.theme_path")."account.transactions",["transactions"=>$transactions]);

    }

    public function order($id){
        $order=OrderRepository::user_find_order($id);
        $products=ProductService::get_cart_products($order->products_id);
        $user_billing=UserRepository::get_billing_meta();

        $pay_statuses=Order::$pay_statuses;
        if(in_array($order->status,$pay_statuses)){
            $products=ProductService::get_cart_products($order->products_id);
            $amount=ProductService::get_cart_products_total_price(false,$products);
            $amount=ShopService::add_delivery_price_to_amount($amount);
            $order->price=$amount;
        }

        return view(config("theme.theme_path")."account.order",["order"=>$order,"products"=>$products,"user_billing"=>$user_billing,"pay_statuses"=>$pay_statuses]);

    }
    public function vip(){
        return view(config("theme.theme_path")."account.vip");

    }


    //admin functions
    public function list_user()
    {
        $users = UserRepository::get_user_with_paginate();
        return view("User::Admin.user_list", ["users" => $users]);
    }

    public function add_user_form(RoleRepo $roleRepo)
    {
        $statuses=User::ACCOUNT_STATUSES;
        $roles= $roleRepo->all();
        return view("User::Admin.user_add", ["statuses" => $statuses,"roles"=>$roles]);
    }

    public function add_user(AddUserRequest $request)
    {

        UserRepository::create($request);

        return redirect()->route("admin_list_user");
    }

    public function edit_user_form($id,RoleRepo $roleRepo)
    {
        $user = UserRepository::find($id);
        $roles= $roleRepo->all();
        $statuses=User::ACCOUNT_STATUSES;
        return view("User::Admin.user_edit", ["user" => $user, "roles" => $roles,"statuses"=>$statuses]);
    }

    public function edit_user(EditUserRequest $request)
    {
        $user = UserRepository::find($request->id);
        if (!empty($request->password)) {
            $pass = bcrypt($request->password);
        } else {
            $pass = $user->password;
        }
        $request->password=$pass;
       UserRepository::update($user,$request);
        return back();
    }

    public function delete_user($id)
    {
        UserRepository::destroy($id);
        return back();
    }

    public function update_profile_info(){
        return view('User::Admin.update_profile_info');
    }

    public function update_profile(update_admins_profile_request $request){
//        $this->authorize('panel_index',User::class);
        $update = $this->userRepo->updateProfileAdmins($request);
        if ($update){
            return redirect()->back()->with('status','updated');
        }else{
            return redirect()->back()->with('status','updated');
        }
    }

    public function update_password(update_password_admins_request $request){
//        $this->authorize('panel_index',User::class);
        $update = $this->userRepo->updateUserPassword($request);
        if ($update){
            return redirect()->back()->with('status','updated');
        }else{
            return redirect()->back()->with('status','error');
        }
    }
}
