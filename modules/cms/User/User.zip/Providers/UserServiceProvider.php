<?php

namespace Mamad\User\Providers;

use Illuminate\Support\ServiceProvider;
use Mamad\User\Models\User;

class UserServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->loadViewsFrom(__DIR__."/../Resources/Views/","User");
        $this->loadRoutesFrom(__DIR__."/../routes/user_route.php");

        $this->loadFactoriesFrom(__DIR__."/../Database/factories");
        $this->loadMigrationsFrom(__DIR__."/../Database/Migrations");
        $this->loadJsonTranslationsFrom(__DIR__."/../Resources/Lang");
        config()->set("auth.providers.users.model",User::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {


        $this->app->booted(function (){
            config()->set("AdminSidebar.user",[
                "name" => "کاربران",
                "link" => route("admin_list_user"),
                "icon" => "fa-user-circle",
                "children" => [
                    ["name"=>"لیست کاربران","link"=>route("admin_list_user")],
                    ["name"=>"اضافه کردن کاربر","link"=>route("admin_add_user")],
                 //   ["name"=>"نقش های کاربری","link"=>route("role-permissions.index")],
                ],
                "permission"=>\Mamad\RolePermissions\Models\Permission::PERMISSION_MANAGE_USERS
            ]);
        });

    }
}
