﻿// Norwegian translation by Vegard S.
CKEDITOR.plugins.setLang('wordcount', 'no', {
    WordCount: 'Ord:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Tegn:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'Tegn (including HTML):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Paragraphs:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Content can not be pasted because it is above the allowed limit',
    Selected: 'Selected: ',
    title: 'Statistikk'
});
