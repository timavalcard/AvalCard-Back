﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'zh', {
    WordCount: '詞數:',
    WordCountRemaining: 'Words remaining',
    CharCount: '字數:',
    CharCountRemaining: '個剩餘字元',
    CharCountWithHTML: '字數 (含HTML)',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: '段落:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: '由於字數達到上限,內容不能粘貼',
    Selected: '已選擇: ',
    title: '統計'
});