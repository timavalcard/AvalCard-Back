﻿/*
Its The Persian (Farsi) Language Translate For Iranian By "Mohsen Esmaili"
*/
CKEDITOR.plugins.setLang('wordcount', 'fa', {
    WordCount: 'لغت:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'کاراکتر:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'کاراکترها (با HTML):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'پاراگراف:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'محتوای مورد نظر را نمی توان چسباند. زیرا این بیشتر از حد مجاز است.',
    Selected: 'انتخاب شده: ',
    title: 'آمار'
});