CKEDITOR.plugins.setLang('wordcount', 'pt', {
    WordCount: 'Palavras:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Caracteres:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: 'Carateres (incluindo HTML):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Parágrafos:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'O conteúdo não pode ser colado porque ultrapassa o limite permitido',
    Selected: 'Selecionado: ',
    title: 'Estatísticas'
});
