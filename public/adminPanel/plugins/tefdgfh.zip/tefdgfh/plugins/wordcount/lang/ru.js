﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'ru', {
    WordCount: 'Слов:',
    WordCountRemaining: 'Words remaining',
    CharCount: 'Символов:',
    CharCountRemaining: 'Characters remaining',
    CharCountWithHTML: ' (включая HTML-разметку):',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: 'Параграфов:',
    ParagraphsRemaining: 'Параграфов осталось',
    pasteWarning: 'Контент не может быть вставлен, т.к. привышает допустимый лимит',
    Selected: 'Выделено: ',
    title: 'Статистика'
});
